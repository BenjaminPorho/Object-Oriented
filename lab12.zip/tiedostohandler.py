'''
@author: Benjamin Pörhö, Oskari Toivanen, Joona Pääkkönen, Jesperi Vainio
tiedostohandler.py
'''


class TiedostoHandler():

    def lue():
        try:
            tiedosto = open("tallennus.txt", "r")
            content = tiedosto.read()
            tiedosto.close()
        except (FileNotFoundError, IOError) as error:
            print(f'Error:{error}')

        return content


    def kirjoita(valinta):
        try:
            tiedosto = open("tallennus.txt", "w")
            lista = []

            for i in valinta:
                lista.append(i)
    
            uusi = str(lista)

            print(uusi)

            valinta = str(valinta)
            tiedosto.write(valinta)
        except (FileNotFoundError, IOError) as error:
            print(f'Error:{error}')