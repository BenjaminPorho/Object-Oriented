'''
@author: Benjamin Pörhö, Oskari Toivanen, Joona Pääkkönen, Jesperi Vainio
noppa.py
'''

from tiedostohandler import TiedostoHandler
from tkinter import messagebox

import random

class Noppa():

    
    def __init__(self):
        self.nopat = {"Cube": 1, "Tetra" : 2, "Octa": 3, "Penta" : 4,"Doca" : 5, "Icos" : 6}
        self.content_list = []
        self.heitot = []
        

    def heitä(self):

        if (len(self.content_list) == 0):
            messagebox.showerror(title="Virhe", message="Valitse ensin noppien määrä ja haluamasi noppa.")
        

        if (self.content_list[0] == 1):
            value = int(self.content_list[1])

            for i in range(value):
                self.luku = random.randint(1,6)
                self.content_list.append(self.luku)
            
            temp = self.content_list.copy()
            self.heitot.append(temp)

            for i in range(value):
                del self.content_list[-1]

        if (self.content_list[0] == 2):
            value = int(self.content_list[1])

            for i in range(value):
                self.luku = random.randint(1,4)
                self.content_list.append(self.luku)

            temp = self.content_list.copy()
            self.heitot.append(temp)

            for i in range(value):
                del self.content_list[-1]
        
        if (self.content_list[0] == 3):
            value = int(self.content_list[1])

            for i in range(value):
                self.luku = random.randint(1,8)
                self.content_list.append(self.luku)

            temp = self.content_list.copy()
            self.heitot.append(temp)

            for i in range(value):
                del self.content_list[-1]
        
        if (self.content_list[0] == 4):
            value = int(self.content_list[1])

            for i in range(value):
                self.luku = random.randint(1,10)
                self.content_list.append(self.luku)

            temp = self.content_list.copy()
            self.heitot.append(temp)

            for i in range(value):
                del self.content_list[-1]

        if (self.content_list[0] == 5):
            value = int(self.content_list[1])

            for i in range(value):
                self.luku = random.randint(1,13)
                self.content_list.append(self.luku)

            temp = self.content_list.copy()
            self.heitot.append(temp)

            for i in range(value):
                del self.content_list[-1]
        
        if (self.content_list[0] == 6):
            value = int(self.content_list[1])

            for i in range(value):
                self.luku = random.randint(1,20)
                self.content_list.append(self.luku)

            temp = self.content_list.copy()
            self.heitot.append(temp)

            for i in range(value):
                del self.content_list[-1]
        

        TiedostoHandler.kirjoita(self.heitot)


        
            