'''
@author: Benjamin Pörhö, Oskari Toivanen, Joona Pääkkönen, Jesperi Vainio
heitto.py
'''


import tkinter as tk
from tkinter import messagebox
import tkinter.ttk as ttk
from tkinter import Frame


from noppa import Noppa
from tiedostohandler import TiedostoHandler


class Heitto(tk.Tk):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.title("Noppapeli")
        self.geometry("400x200")

        self.noppa = Noppa()

        self.luoLayout()

    def onClick(self, button):
        maara = self.__v_maara.get()
        if (len(self.noppa.content_list) < 1):
            self.noppa.content_list.append(button)
            self.noppa.content_list.append(maara)
        else:
            self.noppa.content_list[0] = button
            self.noppa.content_list[1] = maara

        
        keys = list(self.noppa.nopat.keys())
        values = list(self.noppa.nopat.values())
        pos = values.index(self.noppa.content_list[0])

        for i in self.noppa.content_list:
            self.__l_valittu.config(text=f'Valittuna {self.noppa.content_list[1]} kertaa {keys[pos]}')


    def luoLayout(self):
    
        self.columnconfigure(0, pad=3)
        self.columnconfigure(1, pad=3)
        self.columnconfigure(2, pad=3)

        
        self.rowconfigure(0, pad=3)
        self.rowconfigure(1, pad=3)
        self.rowconfigure(2, pad=3)
        self.rowconfigure(3, pad=3)
        self.rowconfigure(4, pad=3)
        self.rowconfigure(5, pad=3)

        self.__v_maara = tk.IntVar()
        self.__v_maara.set(1)

        self.__v_valinta = tk.IntVar()
        self.__v_valinta.set(1)

        self.__l_title = ttk.Label(self, text="Kirjoita ensin noppien määrä,\nvalitse sitten haluamasi noppa.", justify =tk.CENTER)
        self.__l_title.grid(sticky = tk.N + tk.S)

        self.__b_cube = ttk.Button(self, text="Cube", command=lambda : self.onClick(self.noppa.nopat["Cube"]))
        self.__b_cube.grid(row=4, column=1)
        
        self.__b_tetra = ttk.Button(self, text="Tetrahedron", command=lambda : self.onClick(self.noppa.nopat["Tetra"]))
        self.__b_tetra.grid(row=1, column=1)

        self.__b_octa = ttk.Button(self, text="Octahedron", command=lambda : self.onClick(self.noppa.nopat["Octa"]))
        self.__b_octa.grid(row=2, column=3)

        self.__b_penta = ttk.Button(self, text="Pentagonal", command=lambda : self.onClick(self.noppa.nopat["Penta"]))
        self.__b_penta.grid(row=2, column=1)

        self.__b_doce = ttk.Button(self, text="Docacahedron", command=lambda : self.onClick(self.noppa.nopat["Doca"]))
        self.__b_doce.grid(row=3, column=3)

        self.__b_icos = ttk.Button(self, text="Icosahedron", command=lambda : self.onClick(self.noppa.nopat["Icos"]))
        self.__b_icos.grid(row=3, column=1)

        self.__l_maara = ttk.Label(self, text="Kuinka monta noppaa heität?", justify = tk.CENTER)
        self.__l_maara.grid(row=1, column=0)

        self.__e_maara = ttk.Entry(self, textvariable=self.__v_maara)
        self.__e_maara.grid(row=2, column=0)
        
        self.__b_heita = ttk.Button(self, text="Heitä", command=lambda : self.noppa.heitä())
        self.__b_heita.grid(row=3, column=0)

        self.__l_valittu = ttk.Label(self, text='')
        self.__l_valittu.grid(row=4, column=0)


if __name__ == "__main__":
    Heitto().mainloop()